<?php

    // usually an api saves the data to a database and returns the record. 
    // in this case we just echo back what the form gave us.

    // The header is needed to make the json format dispaly correctly inthe browser.
    header('content-Type: application/json');
    echo json_encode($_GET);
?>