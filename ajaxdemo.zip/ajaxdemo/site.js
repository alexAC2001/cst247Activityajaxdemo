$(function(){

    console.log("jQuery is ready");

    // respond to the "get songs" button.
    $("#get-songs-from-api").click(function(){
        console.log("get songs button was clicked");

        $.ajax({
            dataType: "json",
            url: "getsongs.php",
            success: function(songs){
                console.log("Here is the list of songs i got from the server: ");
                console.log(songs);

                $.each(songs, function(i, song){    
                    var songstring = '<li>Title: ' + song.title + ' Artist: ' + song.artist + '</li>';
                    $(songstring).appendTo('#songs').hide().fadeIn(); // The .hide() and .fadeIn() are animations
                    // The element with id="songs" gets appended each time the for-each loop executes.
                })           
             }
        })
    });



    // Add song function
    $("#add-song").click(function() {
        // get the contents of the input lines of the form and put it into a JSON object
        var song = {
            title: $('#artist').val(),
            artist: $('#title').val()
        };

        // send the data to the backend server
        $.ajax({
            type:'GET',
            url:'putsong.php',
            dataType: "json",
            data: song,
            success:function(newsong) {
                // our server just sends back the song we gave it
                // in a real back end, the server should store the data in a database before sending back any data
                console.log("Here is the song the server sent back to us:");
                console.log(newsong);
                var songstring = '<li>Title: ' + newsong.title + ' Artist: ' + newsong.artist + '</li>';
                $(songstring).appendTo('#songs').hide().fadeIn();
            }
        })
    });

});